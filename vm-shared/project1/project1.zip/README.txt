
This project is to explore ElasticSearch, and to setup analyzer for index.

Some area to focus on:
- Create a default Index
- Create Index with whitespace analyzer
- Create Index with custom analyzer