
This project is to explore similarity in ElasticSearch, and to setup custom similarity for index.

Some area to focus on:
- Change default using built-in similarity
- Implement custom similarity plugins